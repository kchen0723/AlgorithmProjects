﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LearnAlgorithm
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("startup");
            Console.Read();
        }
    }
}
